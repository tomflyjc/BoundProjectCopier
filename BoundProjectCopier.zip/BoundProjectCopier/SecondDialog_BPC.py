# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
 Fichier des fonctions du plugin BoundProjectCopier

Produit une copie locale d'un projet donné (couches et projet QGIS) ainsi 
que des tableaux de rapport de dernière copie/mise à jour des couches du projet et du projet lui-même
Vérifie ensuite au lancement si une couche ou le projet a été mis à jour pour garder à jour la version locale.
                              -------------------
        begin                : 2027-07-01 
        deployment           :   
        copyright            : (C) 2027 par Jean-Christophe Baudin 
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/
 icônes produites par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) 
 contact: julie.briand35@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.PyQt.QtWidgets import QDialog, QLabel, QPushButton, QCheckBox, QComboBox, QMessageBox, QVBoxLayout
from qgis.PyQt.QtCore import Qt, QRect
from qgis.PyQt.QtGui import QIcon
import sys
import os
import csv
from pathlib import Path
from pathlib import *
# Get the directory of the current script
current_dir = Path(__file__).parent

# Add the current directory to the Python path
if current_dir not in sys.path:
    sys.path.append(str(current_dir))
    
from .About_BPC  import AboutDialog_BPC
from .BoundProjectCopier import DataManager
from project_updater import *


class SecondUseDialog_BPC(QDialog):
    def __init__(self, data_manager):
        super().__init__()
        self.data_manager = data_manager
        self.setupUi()
        self.DicoProj = self.data_manager.DicoProj
        self.projet_maitre_url = self.data_manager.projet_maitre_url
        self.projet_maitre_name= self.data_manager.projet_maitre_name
        
    def setupUi(self):
        self.setWindowTitle("Bound Project Copier")
        largeur,hauteur= 600, 160  # Directly set the size of the dialog
        self.resize(largeur,hauteur)
                            
        self.label_options = QLabel("Conserver le projet actuel :", self)
        self.label_options.setGeometry(QRect(15, 20, 150, 23))
        
        # récupération et affichage du nom du dernier projet utilisé
        local_folder = self.data_manager.local_folder
        file_name_1 = 'chemin_dernier_projet_maitre.txt'
        texte_file_1 = os.path.join(local_folder, file_name_1)
        try:
            with open(texte_file_1, mode='r', encoding='utf-8') as texte:
                self.data_manager.projet_maitre_url = texte.read().strip()
                self.data_manager.projet_maitre_name = Path(self.data_manager.projet_maitre_url).name
                self.data_manager.projet_maitre_nom_sans_extension=Path(self.data_manager.projet_maitre_url).stem
        except FileNotFoundError:
            projet_maitre_name = "Projet non trouvé"
        self.label_projet = QLabel(self.data_manager.projet_maitre_url, self)
        self.label_projet.setGeometry(QRect(220, 20, 250, 20))
        
        # Create checkboxes
        self.b0 = QCheckBox("Oui", self)
        self.b0.setGeometry(QRect(135, 60, 100, 25))
        if self.data_manager.VarConserver: self.b0.setChecked(True)
        
        self.b1 = QCheckBox("Ajouter", self)
        self.b1.setGeometry(QRect(205, 60, 100, 25))
        
        self.b2 = QCheckBox("Changer", self)
        self.b2.setGeometry(QRect(295, 60, 100, 25))
        
        self.b3 = QCheckBox("Supprimer", self)
        self.b3.setGeometry(QRect(380, 60, 100, 25))

        # Connect each checkbox to the same slot
        self.b0.stateChanged.connect(self.onCheckboxChanged)
        self.b1.stateChanged.connect(self.onCheckboxChanged)
        self.b2.stateChanged.connect(self.onCheckboxChanged)
        self.b3.stateChanged.connect(self.onCheckboxChanged)

        self.aboutButton = QPushButton("À propos...", self)
        self.aboutButton.setGeometry(QRect(15, 120, 100, 25))

        self.WorkButton2 = QPushButton(self)
        self.WorkButton2.setGeometry(QRect(135, 120, 345, 25))

        self.CloseButton = QPushButton("Quitter !", self)
        self.CloseButton.setGeometry(QRect(500, 120, 80, 25))

        self.updateWorkButtonText()

        self.aboutButton.clicked.connect(self.doAbout)
        self.WorkButton2.clicked.connect(self.MAJ)
        self.CloseButton.clicked.connect(self.reject)

    def onCheckboxChanged(self, state):
        # Determine which checkbox triggered the signal
        sender = self.sender()

        if sender == self.b0 and state == Qt.Checked:
            self.b1.setChecked(False)
            self.b2.setChecked(False)
            self.b3.setChecked(False)
        elif sender == self.b1 and state == Qt.Checked:
            self.b0.setChecked(False)
            self.b2.setChecked(False)
            self.b3.setChecked(False)
        elif sender == self.b2 and state == Qt.Checked:
            self.b0.setChecked(False)
            self.b1.setChecked(False)
            self.b3.setChecked(False)
        elif sender == self.b3 and state == Qt.Checked:
            self.b0.setChecked(False)
            self.b1.setChecked(False)
            self.b2.setChecked(False)

        # Update the state variables
        self.data_manager.VarConserver = self.b0.isChecked()
        self.data_manager.VarAjouter = self.b1.isChecked()
        self.data_manager.VarChanger = self.b2.isChecked()
        self.data_manager.VarSupprimer = self.b3.isChecked()
        
        # Update the button text en fonction de choix des cases à cocher
        self.updateWorkButtonText()
        
    
    def updateWorkButtonText(self):
        if self.data_manager.VarConserver:
            self.WorkButton2.setText("Mettre à jour et ouvrir le projet local !")
        elif self.data_manager.VarAjouter:
            self.WorkButton2.setText("Ajouter un nouveau projet lié à recopier/suivre en local !")
        elif self.data_manager.VarChanger:
            self.WorkButton2.setText("Changer de projet local lié actuel à mettre à jour !")
        elif self.data_manager.VarSupprimer:
            self.WorkButton2.setText("Supprimer le projet local lié actuel !")

    def retranslateUi(self):
        self.setWindowTitle("BoundProjectCopier")

    def doAbout(self):
        d = AboutDialog_BPC.Dialog()
        d.exec_()
       
    def MAJ(self):
        if self.data_manager.VarConserver:
            print("Conserver le projet actuel")
            # on lit quel est le dernier projet utilisé, c'est à dire le projet actuel on récupère son nom
            file_name_1='chemin_dernier_projet_maitre.txt'
            texte_file_1 = os.path.join(self.data_manager.local_folder, file_name_1 )
            try:
                with open(texte_file_1, mode='r', encoding='utf-8') as texte:
                    projet_maitre_url_actuel = texte.read().strip()  # Lire le contenu du fichier et supprimer les espaces superflus
                projet_maitre_name = Path(projet_maitre_url_actuel).stem
                print(f"Projet Maître URL: {projet_maitre_url_actuel}")
                print(f"Projet Maître Name: {projet_maitre_name}")
            except FileNotFoundError:
                print("Le fichier spécifié est introuvable.")
            
            # on lit aussi le dictionnaire des projets
            Dico = {}
            #DicoProj[projet_maitre_name]=[projet_maitre_root,projet_maitre_url,chemin,project_local_name,project_qgs_name,liste_locale_des_couches] 
            file_name_2 = 'bound_projet_dictionnary.csv'
            csv_file = os.path.join(self.data_manager.local_folder, file_name_2)
            try:
                with open(csv_file, mode='r', newline='', encoding='utf-8') as file:
                    reader = csv.reader(file, delimiter=';')
                    for ligne in reader:
                         # ligne[0]=projet_maitre_name, 
                         # ligne[1]=projet_maitre_root, 
                         # 2 = projet_maitre_url, 
                         # 3 = chemin,
                         # 4 = project_local_name, 
                         # 5 = project_qgs_name,
                         # 6 =liste_locale_des_couches, 
                        Dico[ligne[0]]=[ligne[1],ligne[2],ligne[3],ligne[4],ligne[5],ligne[6]]
                       
            except FileNotFoundError:
                QMessageBox.information(None, "Erreur", "Le fichier spécifié est introuvable.")
                return
            
            # Une action de suppression a t'elle supprimé le dernier projet lié ?
            if len(Dico) == 0:
                print("Le dictionnaire est vide.")
                self.data_manager.DicoVide=True
                if os.path.exists(self.data_manager.local_folder):
                    shutil.rmtree(self.data_manager.local_folder)
                    QMessageBox.information(None, "Avertissement : ", f"Le dossier '{self.data_manager.local_folder}' a été supprimé car il n'y a plus de projet lié.")

            #QMessageBox.information(None, "debug MAJ DicoProjet:", "Dico lu depuis csv: " + str(Dico))
            # DicoProj[projet_maitre_name]=[Selection_repertoire,projet_maitre_url,chemin,project_local_name,project_qgs_name,liste_locale_des_couches] 
            # on récupère dans le csv qui contient le dictionnaire les infos du projet actuel
            # Pour aller vérifier la date de dernière mise à jour

            for projet_maitre_name in Dico.keys():
                        
                if self.data_manager.projet_maitre_nom_sans_extension == projet_maitre_name:
                #if  self.data_manager.projet_maitre_name+'.qgz' == projet_maitre_name:
                    Selection_repertoire, projet_maitre_url, chemin, project_local_name, project_qgs_name, liste_locale_des_couches = Dico[projet_maitre_name]
                    if not os.path.exists(chemin):
                        QMessageBox.information(None, "information:", "Le dossier appelé: Projet_lie_" + str(projet_maitre_name) + '\n' + '\n' +
                            "sur: " + str(chemin) + '\n' +
                            "a été supprimé ou renommé! " + '\n' + '\n' +
                            "Il faut l'y replacer ou relancer le plugin après avoir supprimé manuellement le dossier: projet_local" + '\n' + '\n' +
                            "placé dans: " + '\n' + '\n' + str(self.data_manager.local_folder))
                    
                    # Sinon il existe à priori un projet .qgz, on vérifie la mise à jour du projet et des couches.
                    # De quand date la dernière utilisation ? 
                    current_day, date_locale_last_use = check_and_update_last_verif_date(chemin)
                    # Quel est le jour de dernière utilisation en fait ?
                    QMessageBox.information(None, "Information:", "Aujourd'hui nous sommes le: " + str(current_day) + '\n' + '\n' +
                        "Et la date de dernière vérification pour ce projet est: " + str(date_locale_last_use)+ '\n' + '\n' +
                        "Pour rappel, si c'est la même, il n'y a pas de mise à jour du projet local ou de ses couches.")

                    if current_day != date_locale_last_use:
                        # Comparer la date actuelle avec la date sauvegardée
                        # on ne met à jour les données qu'une fois par jour !
                        # le dossier local existe alors vérifions encore ...
                        QMessageBox.information(None, "information:", "Comme aujourd'hui nous sommes le: " + str(current_day) +' ,'+ '\n' + '\n' +
                        "et que la date de dernière vérification pour ce projet est: " + str(date_locale_last_use)+' ,'+ '\n' + '\n' +
                        "avant d'ouvrir le projet local, on vérifie: " + '\n' + '\n' +
                            "- si le projet maître: " + str(projet_maitre_name) + " a été modifié, " + '\n' +
                            "- si les couches qui le composent ont été modifiées. " + '\n' + '\n' +
                            "Ceci peut prendre plusieurs minutes....")
                        
                        # Le projet Maitre a aussi pu etre modifié
                        # on vérifie si il y a eu ajout ou suppression de couche
                        # et on met éventuellement encore à jour:couches et projet local et rapports !
                        verif_update_project(projet_maitre_url, projet_maitre_name, chemin)
                        QMessageBox.information(None, "information:", "Fin de la vérification de la mise à jour du projet maître")

                        # Le projet maître peut ne pas avoir changé mais les couches qui le composent si...
                        # vérification des dernières mise à jour des couches
                        update_layers(liste_locale_des_couches, chemin)
                        QMessageBox.information(None, "information:", "Fin de la vérification de la mise à jour des couches")
                        
                        # Si tout est Ok on ouvre le projet local   
                        # Ouvrir le projet local
                        projet_local_lu = QgsProject.instance()
                        projet_local_lu.read(os.path.join(chemin, project_local_name))

                    else:# le plugin a déjà été utilisé aujourd'hui, on ne met pas à jour les couches
                        # Vérifier si un projet est actuellement ouvert ?
                        current_project_path = QgsProject.instance().fileName()
                        project_local_path = os.path.join(chemin, project_local_name)
                        # Est-ce que le projet qui est ouvert est le bon ? 
                       
                        if project_local_path == current_project_path:
                            pass # Alors on continue
                        # Dans ce cas le projet n'est pas à réouvrir, 
                        # ce qui permet de sélectionner plusieurs parcelles !
                        else:
                            # Ouvrir le projet local car le projet ouvert n'est pas le bon
                            projet_local_lu = QgsProject.instance()
                            projet_local_lu.read(project_local_path)
                            #QMessageBox.information(None, "debug MAJ:", "projet_local_lu: " + str(projet_local_lu))
                            self.accept()  # Ferme la fenêtre actuelle de SecondDialog_BPC
        elif self.data_manager.VarAjouter:
            print("Ajouter un nouveau projet")  
            from .InitialDialog_BPC import InitialDialog_BPC
            self.accept()  # Ferme la fenêtre actuelle
            self.dialogInitial = InitialDialog_BPC(self.data_manager)
            # self.dialog.show() 
            # Utilisez show() pour une fenêtre non modale (elle reste ouverte) 
            #  c'est à dire que l'utilisateur peut continuer à interagir avec d'autres fenêtres de l'application tout en laissant cette fenêtre ouverte
            self.dialogInitial.exec_() # Ouvre la fenêtre modale
            # l'utilisateur doive fermer cette fenêtre avant de pouvoir continuer à utiliser le reste de l'application, 
            
        
        elif self.data_manager.VarChanger:
            print("Changer le projet actuel") 
            from .ChangeDialog_BPC import ChangeDialog_BPC
            self.accept()  # Ferme la fenêtre actuelle
            self.ChangeDialog_BPC=ChangeDialog_BPC(self.data_manager)
            self.ChangeDialog_BPC.exec_() # Ouvre la fenêtre modale

                  
        elif self.data_manager.VarSupprimer:
            print("Supprimer le projet actuel")     
            from .SuppressDialog_BPC import SuppressDialog_BPC
            self.accept()  # Ferme la fenêtre actuelle
            self.SuppressDialog_BPC=SuppressDialog_BPC(self.data_manager)
            self.SuppressDialog_BPC.exec_() # Ouvre la fenêtre modale
            
            
     