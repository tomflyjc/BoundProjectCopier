# -*- coding: utf-8 -*-
# Python 3

def classFactory(iface):
    from .BoundProjectCopier import MainPluginBPC
    return MainPluginBPC(iface)


