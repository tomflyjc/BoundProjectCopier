# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
 Fichier des fonctions du plugin BoundProjectCopier

Produit une copie locale d'un projet donné (couches et projet QGIS) ainsi 
que des tableaux de rapport de dernière copie/mise à jour des couches du projet et du projet lui-même
Vérifie ensuite au lancement si une couche ou le projet a été mis à jour pour garder à jour la version locale.
                              -------------------
        begin                : 2025-06-16 
        deployment           :   
        copyright            : (C) 2025 par Jean-Christophe Baudin 
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/
 icônes produites par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) 
 contact: julie.briand35@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
"""
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import *
from qgis.utils import iface
from qgis.core import *
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
                       )
"""
from qgis.PyQt.QtWidgets import QDialog, QLabel, QPushButton, QComboBox, QMessageBox
from qgis.PyQt.QtCore import Qt, QSize, QRect, QFile
from qgis.core import QgsProject, QgsMapLayer

import shutil

from pathlib import *
import sys
import os

from .About_BPC  import AboutDialog_BPC
from .BoundProjectCopier import DataManager
from project_updater import *

# Get the directory of the current script
current_dir = Path(__file__).parent

# Add the current directory to the Python path
if current_dir not in sys.path:
    sys.path.append(str(current_dir))


class ChangeDialog_BPC(QDialog):
    def __init__(self, data_manager):
        super().__init__()
        self.data_manager = data_manager
        self.setupUi()

    def setupUi(self):
        
        self.setObjectName("Dialog")
        self.resize(QSize(500, 200))

        self.label10 = QLabel(self)
        self.label10.setGeometry(QRect(15, 20, 450, 18))
        self.label10.setObjectName("label10")
        self.label10.setText("Choisir un projet déjà utilisé à ouvrir et mettre à jour:")

        
        self.projet_ComboBox = QComboBox(self)
        self.projet_ComboBox.setGeometry(QRect(300, 20, 180, 23))
        self.projet_ComboBox.setObjectName("Proj_ComboBox")
        self.projet_ComboBox.setObjectName("Proj_Chang_ComboBox")

        Liste_projet = [""]
        for projet_maitre_name in list(self.data_manager.DicoProj.keys()):
            Liste_projet.append(projet_maitre_name)
        Liste_projet.sort()
        for projet in Liste_projet:
            self.projet_ComboBox.addItem(projet)

        self.aboutButton = QPushButton(self)
        self.aboutButton.setGeometry(QRect(15, 150, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText("A propos...")

        self.WorkButtonChange = QPushButton(self)
        self.WorkButtonChange.setGeometry(QRect(100, 150, 300, 23))
        self.WorkButtonChange.setObjectName("WorkButtonChange")
        self.WorkButtonChange.setText("Ouvrir et mettre à jour le projet local choisi!")

        self.CloseButton = QPushButton(self)
        self.CloseButton.setGeometry(QRect(410, 150, 80, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText("Quitter!")

        self.aboutButton.clicked.connect(self.doAbout)
        self.WorkButtonChange.clicked.connect(self.Change)
        self.CloseButton.clicked.connect(self.reject)

        self.retranslateUi()

    def retranslateUi(self):
        self.setWindowTitle("BoundProjectCopier")

    def doAbout(self):
        from .About_BPC import AboutDialog_BPC
        d = AboutDialog_BPC.Dialog()
        d.exec_()

    def Change(self):
        Selection_projet_Chang = self.projet_ComboBox.currentText()
        if Selection_projet_Chang:  # Vérifiez si un projet est sélectionné
            for projet_maitre_name in list(self.data_manager.DicoProj.keys()):
                if Selection_projet_Chang == projet_maitre_name:
                    Selection_repertoire, projet_maitre_url, chemin, project_local_name, project_qgs_name, liste_locale_des_couches = self.data_manager.DicoProj[projet_maitre_name]
                    # on récupère dans le csv qui contient le dictionnaire les infos du projet actuel
                    # Pour aller vérifier la date de dernière mise à jour
                    if not os.path.exists(chemin):
                        QMessageBox.information(None, "information:", "Le dossier appelé: Projet_lie_" + str(self.data_manager.projet_maitre_name) + '\n' + '\n' +
                        "sur: " + str(chemin) + '\n' +
                        "a été supprimé ou renommé! " + '\n' + '\n' +
                        "Il faut l'y replacer ou relancer le plugin après avoir supprimé manuellement le dossier: projet_local" + '\n' + '\n' +
                        "placé dans: " + '\n' + '\n' + str(self.data_manager.local_folder))
                
                    # Sinon il existe à priori un projet .qgz, on vérifie la mise à jour du projet et des couches.
                    # De quand date la dernière utilisation ? 
                    current_day, date_locale_last_use = check_and_update_last_verif_date(chemin)
                    # Quel est le jour de dernière utilisation en fait ?
                    QMessageBox.information(None, "Information:", "Aujourd'hui nous sommes le: " + str(current_day) + '\n' + '\n' +
                        "Et la date de dernière vérification pour ce projet est: " + str(date_locale_last_use)+ '\n' + '\n' +
                        "Pour rappel, si c'est la même, il n'y a pas de mise à jour du projet local ou de ses couches.")

                    if current_day != date_locale_last_use:
                        # Comparer la date actuelle avec la date sauvegardée
                        # on ne met à jour les données qu'une fois par jour !
                        # le dossier local existe alors vérifions encore ...
                        QMessageBox.information(None, "information:", "Comme aujourd'hui nous sommes le: " + str(current_day) +' ,'+ '\n' + '\n' +
                        "et que la date de dernière vérification pour ce projet est: " + str(date_locale_last_use)+' ,'+ '\n' + '\n' +
                        "avant d'ouvrir le projet local, on vérifie: " + '\n' + '\n' +
                        "- si le projet maître: " + str(projet_maitre_name) + " a été modifié, " + '\n' +
                        "- si les couches qui le composent ont été modifiées. " + '\n' + '\n' +
                        "Ceci peut prendre plusieurs minutes....")
                    
                        # Le projet Maitre a aussi pu etre modifié
                        # on vérifie si il y a eu ajout ou suppression de couche
                        # et on met éventuellement encore à jour:couches et projet local et rapports !
                        verif_update_project(projet_maitre_url, projet_maitre_name, chemin)
                        QMessageBox.information(None, "information:", "Fin de la vérification de la mise à jour du projet maître")

                        # Le projet maître peut ne pas avoir changé mais les couches qui le composent si...
                        # vérification des dernières mise à jour des couches
                        update_layers(liste_locale_des_couches, chemin)
                        QMessageBox.information(None, "information:", "Fin de la vérification de la mise à jour des couches")
                    
                        # Si tout est Ok on ouvre le projet local   
                        # Ouvrir le projet local
                        projet_local_lu = QgsProject.instance()
                        projet_local_lu.read(os.path.join(chemin, project_local_name))

                    else:# le plugin a déjà été utilisé aujourd'hui, on ne met pas à jour les couches
                        # Vérifier si un projet est actuellement ouvert ?
                        current_project_path = QgsProject.instance().fileName()
                        project_local_path = os.path.join(chemin, project_local_name)
                        # Est-ce que le projet qui est ouvert est le bon ? 
                   
                        if project_local_path == current_project_path:
                            pass # Alors on continue
                        # Dans ce cas le projet n'est pas à réouvrir, 
                        # ce qui permet de sélectionner plusieurs parcelles !
                        else:
                            # Ouvrir le projet local car le projet ouvert n'est pas le bon
                            projet_local_lu = QgsProject.instance()
                            projet_local_lu.read(project_local_path)
                            #QMessageBox.information(None, "debug MAJ:", "projet_local_lu: " + str(projet_local_l
                    
                    file_name_1='chemin_dernier_projet_maitre.txt'
                    texte_file_1 = os.path.join(self.data_manager.local_folder, file_name_1 )
                    with open(texte_file_1, mode='w', encoding='utf-8') as texte:
                        texte.write(projet_maitre_url)
                    """
                    QMessageBox.information(None, "Debug : ", f"Le projet - project_local_name '{projet_maitre_name}' est désormais le projet courant." 
                    + '\n' + "chemin : "+ str(chemin)+'\n' +
                     "projet_maitre_url : "+ str(projet_maitre_url))
                    """
                    self.data_manager.VarChanger=False     
                    self.data_manager.VarConserver=True
                    self.data_manager.projet_maitre_url=projet_maitre_url   
                    self.data_manager.projet_maitre_name=projet_maitre_name                    
                    
                    QgsProject.instance().clear()
                    # On crée le csv avec la date du jour comme date de première utilisation
                    # C'est la première utilisation, le jour de dernière utilisation est celui de la première en fait
                    current_day,date_locale_last_use=check_and_update_last_verif_date(chemin) 
                    
                     
                    # Si tout est Ok on ouvre le projet local   
                    # Ouvrir le projet local
                    projet_local = QgsProject.instance()
                    projet_local.read(os.path.join(chemin, project_local_name))
                    #QMessageBox.information(None, "Avertissement : ", f"Le projet '{projet_maitre_name}' est désormais le projet courant.")
                     
                    self.accept()
                    """
                    from .SecondDialog_BPC import SecondUseDialog_BPC
                      # Ferme la fenêtre actuelle de ChangeDialog_BPC
                    self.SecondUseDialog_BPC=SecondUseDialog_BPC(self.data_manager)
                    self.SecondUseDialog_BPC.exec_() # Ouvre la fenêtre modale
                    """
        
        
         