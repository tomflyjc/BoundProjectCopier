# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
  plugin BoundProjectCopier

Produit une copie locale d'un projet donné (couches et projet QGIS) ainsi 
que des tableaux de rapport de dernière copie/mise à jour des couches du projet et du projet lui-même
Vérifie ensuite au lancement si une couche ou le projet a été mis à jour pour garder à jour la version locale.
                              -------------------
        begin                : 2025-06-16 
        deployment           :   
        copyright            : (C) 2025 par Jean-Christophe Baudin 
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/
 icônes produites par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) 
 contact: julie.briand35@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import *
from qgis.utils import iface
from qgis.core import *
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
                       )

import shutil
import csv

from datetime import datetime

import zipfile
import sys, csv
import os
from pathlib import *
# Get the directory of the current script
current_dir = Path(__file__).parent

# Add the current directory to the Python path
if current_dir not in sys.path:
    sys.path.append(str(current_dir))
    
from .About_BPC  import AboutDialog_BPC
from .BoundProjectCopier import DataManager
from project_updater import *


#Fonction de reconstruction du chemin absolu vers une ressource du plugin
def resolve(name, basepath=None):
  if not basepath:
    basepath = os.path.dirname(os.path.realpath(__file__))
  return os.path.join(basepath, name)  

def getThemeIcon(theName):
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons =basepath + "/icons/"
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    if QFile.exists(myDefPathIcons): return myDefPathIcons  
    else: return ""
    
def get_plugin_directory():
    # Obtenir le chemin du fichier courant
    current_file_path = os.path.abspath(__file__)
    # Déterminer le répertoire parent (le dossier du plugin)
    plugin_directory = os.path.dirname(current_file_path)
    return plugin_directory    

def getVectorLayerByName(NomCouche):
    layermap=QgsProject.instance().mapLayers()
    for name,layer in layermap.items():
        if layer.type()==QgsMapLayer.VectorLayer and layer.name()== NomCouche:
            if layer.isValid():
               return layer
            else:
               return None

class InitialDialog_BPC(QDialog):
    def __init__(self, data_manager): # Use super() to properly initialize the QDialog
        super(InitialDialog_BPC, self).__init__()  # Correctly initialize the superclass
        self.data_manager = data_manager
        self.setupUi()  # Call setupUi without passing self as an argument
        

    def setupUi(self):
        #  Fabrication de l'interface   
        # L'interface est différente selon qu'on utilise pour la première fois ou pas le plugin
         
        local_folder=self.data_manager.local_folder
        
        self.setObjectName("Dialog")
        largeur,hauteur= 500, 220  # Directly set the size of the dialog
        self.resize(largeur,hauteur)
        #self.setObjectName("Dialog")
        #self.resize(QtCore.QSize(QtCore.QRect(0,0,500,240).size()).expandedTo(Dialog.minimumSizeHint()))
        self.setWindowTitle("Bound Project Copier")
        
        #QRect(0,0,largeur,hauteur)

        # QLabel lancer recherche
        self.label10 = QLabel(self)
        self.label10.setGeometry(QtCore.QRect(15,20,450,18))
        self.label10.setObjectName("label10")
        self.label10.setText(" Sélectionner un projet à recopier localement :  ")
       
            
        #Exemple de QLabel  
        self.label = QLabel(self)
        self.label.setGeometry(QtCore.QRect(15,50,80,23))
        self.label.setObjectName("label")
        self.label.setText("<b>Projet : </b>")
        
        # QgsFileWidget pour sélectionner un fichier
        # https://api.qgis.org/api/classQgsFileWidget.html#a08386cb46b9515dd50193a6de73d1db2
        self.folder_widget1 = QgsFileWidget(self)
        self.folder_widget1.setGeometry(QtCore.QRect(100, 50, 380, 23))
        self.folder_widget1.setObjectName("Chemin")
        #https://gis.stackexchange.com/questions/463676/where-in-qgis-plugin-code-should-i-set-the-qgsfilewidget-to-getdirectory
        self.folder_widget1.setStorageMode(QgsFileWidget.StorageMode.GetFile)
        #self.folder_widget.setFilter("Fichiers de projet QGIS (*.qgz *.qgs)")
       
        self.label = QLabel(self)
        self.label.setGeometry(QtCore.QRect(15,80,300,18))
        self.label.setObjectName("label")
        self.label.setText("<b>Choisir un dossier d'export des résultats : </b>")
        
        self.folder_widget2 = QgsFileWidget(self)
        # https://api.qgis.org/api/classQgsFileWidget.html#a08386cb46b9515dd50193a6de73d1db2
        self.folder_widget2.setGeometry(QtCore.QRect(15,110,460,23))
        self.folder_widget2.setObjectName("Chemin")
        #https://gis.stackexchange.com/questions/463676/where-in-qgis-plugin-code-should-i-set-the-qgsfilewidget-to-getdirectory
        self.folder_widget2.setStorageMode(QgsFileWidget.StorageMode.GetDirectory)
        
        # Exemple de QPushButton
        self.WorkButton = QPushButton(self)
        self.WorkButton.setMinimumSize(QtCore.QSize(290, 20))
        self.WorkButton.setMaximumSize(QtCore.QSize(290, 20))        
        self.WorkButton.setGeometry(QtCore.QRect(100, 140, 290, 23))
        self.WorkButton.setObjectName("Traitement")
        self.WorkButton.setText("Recopier les données")

        #Exemple de QPushButton
        self.aboutButton = QPushButton(self)
        self.aboutButton.setMinimumSize(QtCore.QSize(70, 20))
        self.aboutButton.setMaximumSize(QtCore.QSize(70, 20))        
        self.aboutButton.setGeometry(QtCore.QRect(15, 140, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText(" A propos...")
        
        #Exemple de QPushButton
        self.CloseButton = QPushButton(self)
        self.CloseButton.setMinimumSize(QtCore.QSize(70, 20))
        self.CloseButton.setMaximumSize(QtCore.QSize(70, 20))        
        self.CloseButton.setGeometry(QtCore.QRect(405, 140,70, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText(" Quitter !")
        #-----------------------------------------------------------------------------------------------------------
        #                                    Connexion des slots et des actions liées
        #-----------------------------------------------------------------------------------------------------------
        self.aboutButton.clicked.connect(self.doAbout)
        self.WorkButton.clicked.connect(self.LocalCopy)
        self.CloseButton.clicked.connect(self.reject)
        # Connecter les signaux fileChanged pour obtenir les chemins sélectionnés
        self.folder_widget1.fileChanged.connect(self.Lecture)
        self.folder_widget2.fileChanged.connect(self.Exports)
        
        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)
  
    #-----------------------------------------------------------------------------------------------------------   
    #                                      Définitions des actions que lancent les slots   
    #-----------------------------------------------------------------------------------------------------------
          
    def retranslateUi(self):
        self.setWindowTitle("BoundProjectCopier")
       
    def doAbout(self):
        d = AboutDialog_BPC.Dialog()
        d.exec_()

    def Lecture(self):
        # Vérifier si le fichier sélectionné est un projet QGIS
        Selection_fichier = self.folder_widget1.filePath()
        if Selection_fichier.lower().endswith(('.qgs', '.qgz')):
            projet_maitre_url_selec = Selection_fichier
            self.data_manager.projet_maitre_url=projet_maitre_url_selec
        else:
            # Afficher un message d'erreur si le fichier n'est pas un projet QGIS
            QMessageBox.information(self, "Erreur", "Veuillez sélectionner un fichier de projet QGIS valide (.qgs ou .qgz).")
                    
    def Exports(self):
        # deux actions, on lit et stocke le répertoire choisi pour copier le projet 
        # 1) dans la variable globale: repertoire_local
        global repertoire_local
        repertoire_local = self.folder_widget2.filePath()
        #QMessageBox.information(None,"Debug:"," repertoire_local: "+'\n'+ str(repertoire_local) + '\n')
       
    def LocalCopy(self):    
        # ----------------------------------------------------------------------------------------------------------------------------- 
        #                            Sauvegarde et exports des couches et du projet selectionné       
        # ----------------------------------------------------------------------------------------------------------------------------- 
        counter_export=0
        DicoProj=self.data_manager.DicoProj
        local_folder=self.data_manager.local_folder
        # on va créer une liste des couches au même instant t avec leurs dernières dates de modification    
        global chemin
        chemin=''
        #date = datetime.strftime(datetime.now(), "%Y_%m_%d_%H_%M_%S") # or "%Y%m%d_%H%M%S"
        date = datetime.strftime(datetime.now(), "%Y_%m_%d")
        date_H_M=datetime.strftime(datetime.now(), "%Y_%m_%d_%Hh_%Mmin")
        #QMessageBox.information(None,"debug LocalCopy:"," repertoire_local: " +str(repertoire_local))
        if len(str(self.data_manager.projet_maitre_url))>1: 
            repertoire=self.data_manager.projet_maitre_url
            file_name_1='chemin_dernier_projet_maitre.txt'
            texte_file_1 = os.path.join(local_folder, file_name_1 )
            with open(texte_file_1, mode='w', encoding='utf-8') as texte:
                    texte.write(repertoire)

        else:   
            QMessageBox.information(None,"Attention:"," Pas de répertoire, dans le fichier"+ str(local_folder)+" appelé chemin_projet_maitre.txt")
                        
        # lecture du projet Maitre
        # En utilisant de la bibliothèque pathlib :
        projet_maitre_root = Path(self.data_manager.projet_maitre_url).parent
        # Nom du fichier sans l'extention : 
        projet_maitre_name = Path(self.data_manager.projet_maitre_url).stem
         
        # définition du nom et du chemin du futur projet local 
        project_local_name = f"{projet_maitre_name}_local.qgz"
        # nom et chemin du projet qgs produit en local à la lecture du projet maitre
        project_qgs_name= f"{projet_maitre_name}.qgs"
        # nom du tableur qui contiendra la liste des couches contenues dans le projet Maître
        liste_locale_des_couches = 'rapport_couches_'+ projet_maitre_name +'.csv'
        chemin = str(repertoire_local)+str('/')+'Projet_lie_'+str(projet_maitre_name)+str('/')
 
        DicoProj[projet_maitre_name]=[projet_maitre_root,self.data_manager.projet_maitre_url,chemin,project_local_name,project_qgs_name,liste_locale_des_couches] 
        # Dans un csv appelé 'bound_projet_dictionnary' dans le dossier 'projet_local' du plugin
        file_name ='bound_projet_dictionnary.csv'
        txt_file = os.path.join(local_folder, file_name )
        
        # Writing to a CSV file
        with open(txt_file, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file, delimiter=';')  # Specify the delimiter here
            for key, values in DicoProj.items():
                writer.writerow([key] + values)
        self.data_manager.DicoProj = DicoProj
 
        # Cas de la première utilisation sur un poste: on va recopier couches et projet et créer des rapports
        if not os.path.exists(chemin):
            os.makedirs(chemin)
            # On ferme tout projet ouvert par précaution ! 
            QgsProject.instance().clear()
            if self.data_manager.VarAjouter: 
                toto= " Avertissement, c'est une nouvelle utilisation de l'outil Bound Project Copier sur ce poste"
            else: 
                toto = "Avertissement, c'est la première utilisation de l'outil Bound Project Copier sur ce poste. "           
                QMessageBox.information(None,"information:",  toto +
                    '\n'+'\n'+ ' Le projet qgis "maître" se nomme :  '+str(projet_maitre_name)+'\n'+ 
                    '- il provient de: '+'\n'+ 
                    str(self.data_manager.projet_maitre_url) +'\n'+'\n'+
                    'Le plugin Bound Project Copier, va le recopier localement en créant: ' +'\n'+ 
                    'une copie locale du projet (avec toutes les couches associées) nommée : '+str(project_local_name)  +'\n'+ 
                    'Cet ensemble couches recopiées et projet local sera placé dans : ' + str(chemin)+'\n'+'\n'+
                    "Lors d'une utilisation ultérieure, une seule fois par jour, l'outil vérifie si le projet QGIS et les couches qui le composent ont évolué, été mis à jour."+'\n'+ 
                    "Toute modification du projet et des données se répercute en local. Mais une modification le jour même ne sera donc prise en compte que le lendemain."+'\n'+'\n'+ 
                    "Attention : il faut s'assurer de disposer d'assez d'espace disque et s'armer de patience, "+'\n'+ 
                    "et attendre jusqu'à l'apparition d'un prochain message ! ") 
            # lecture du projet Maitre
            # projet_maitre = QgsProject.instance()
            # projet_maitre.read(self.data_manager.projet_maitre_url) # ouvre le projet si pas de couches manquantes!
            # projet_maitre,missing_layers_list=load_project_with_missing_layers(self.data_manager.projet_maitre_url) # ouvre le projet même si couche manquantes
            projet_maitre=load_project_with_filters_and_missing_layers(self.data_manager.projet_maitre_url)
            
            #projet_maitre_name = (projet_maitre.fileName().split('/')[-1]).split('.')[0]
                     
            # création des rapports sur le projet Maitre avec date mise à jour
            createur_csv_rapport_project(projet_maitre, chemin)
            
            # création des rapports sur les couches du projet Maitre avec date mise à jour
            createur_csv_rapport_layer(projet_maitre, chemin)
            
            # Créer le projet local avec les couches locales 
            output_project_path = create_local_project_with_local_layers_2(projet_maitre_name,self.data_manager.projet_maitre_url, chemin)
            
            # Fermer le projet de départ
            QgsProject.instance().clear()
            # On crée le csv avec la date du jour comme date de première utilisation
            # C'est la première utilisation, le jour de dernière utilisation est celui de la première en fait
            current_day,date_locale_last_use=check_and_update_last_verif_date(chemin) 
            # Si tout est Ok on ouvre le projet local   
            # Ouvrir le projet local
            projet_local_lu = QgsProject.instance()
            projet_local_lu.read(os.path.join(chemin, project_local_name))
            #projet_local_lu.read(chemin) # ouvre le projet !
            
            
        ##########################################################################
        #         Vérification  de la présence de la copie locale du projet 
        #                 "Maitre"  et des données liées 
        ##########################################################################
            
        # Si il existe un dossier local, est-ce pour autant que la copie des couches s'est bien faite ?
        # si c'est le cas , le processus doit s'etre achevé avec la production du projet local.qgz
        # existe t'il un tel projet ?
        if not os.path.exists(output_project_path):
            QMessageBox.information(None,"information:","Attention, il y a un problème car il n'y a pas de projet local nommé : "+ 
            str(project_local_name)+'\n' +
            " dans le dossier : " + str(chemin)+'\n' +
            ' selon le chemin : '+ str(output_project_path))
            # la copie des couches avait elle commencé ? Existe t'il un projet gqs produit au début du processus ?   
            if os.path.exists(chemin):
                QMessageBox.information(None,"information:","La création du projet_local n'a pas abouti."+'\n'+
                'Mais il existe bien un projet .qgs qui correspond à une début de copie des données en local !'+'\n'+'\n'+
                "Il y a donc eu un problème après que le projet : "+ 
                str(project_qgs_name)+ " ai été créé dans : " +'\n'+ str(chemin)+'\n'+'\n'+ 
                '... Ce pourquoi on reprend le chargement des couches et on refabrique le projet .qgz')
                update_layers(liste_locale_des_couches, chemin)
                with zipfile.ZipFile(project_local_path, 'w') as z:
                    # Ajouter uniquement le fichier .qgs modifié
                    z.write(project_local_path, arcname=project_qgs_name)
                    # Si tout est Ok on ouvre le projet local   
                    # Ouvrir le projet local
                projet_local_lu = QgsProject.instance()
                projet_local_lu.read(project_local_path)
                
            else: # pb inconnu !
                QMessageBox.information(None,"information:","il n'y pas de projet local : "+'\n'+
                    str(project_qgs_name) +'\n'+
                    'dans le dossier local : '+'\n'+ str(chemin)+'\n'+'\n'+
                    "Un problème innatendu est survenu. "+'\n'+
                    'Supprimer ce dossier et relancer le plugin !')
                # Fermer la boîte de dialogue
                Dialog.reject() 
        QMessageBox.information(None,"Avertissement:"," Fin des traitements ! \n\nLes exports sont dans le dossier :\n" + str(chemin) )
       
        self.accept() 