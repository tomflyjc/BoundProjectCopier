# -*- coding: utf-8 -*-
# Python 3


"""
/***************************************************************************
  plugin BoundProjectCopier

Produit une copie locale d'un projet donné (couches et projet QGIS) ainsi 
que des tableaux de rapport de dernière copie/mise à jour des couches du projet et du projet lui-même
Vérifie ensuite au lancement si une couche ou le projet a été mis à jour pour garder à jour la version locale.
                              -------------------
        begin                : 2025-06-16 
        deployment           :   
        copyright            : (C) 2025 par Jean-Christophe Baudin 
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/
 icônes produites par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) 
 contact: julie.briand35@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject

from qgis.core import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *

from .About_BPC  import AboutDialog_BPC

import os
import csv


#Fonction de reconstruction du chemin absolu vers la ressource image
def resolve(name, basepath=None):
  if not basepath:
    basepath = os.path.dirname(os.path.realpath(__file__))
  return os.path.join(basepath, name)  
  
def getThemeIcon(theName):
    # icônes produite par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) contact: julie.briand35@gmail.com
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons =basepath + "/icons/"
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    if QFile.exists(myDefPathIcons): return myDefPathIcons  
    else: return ""
    
def get_plugin_directory():
    # Obtenir le chemin du fichier courant
    current_file_path = os.path.abspath(__file__)
    # Déterminer le répertoire parent (le dossier du plugin)
    plugin_directory = os.path.dirname(current_file_path)
    return plugin_directory 
    
####################################################################################
class DataManager:
    def __init__(self):
        super().__init__()
        
        self.basepath=get_plugin_directory() #  est le répertoire où se trouve le plugin
        self.projet_maitre_url = None  # Variable pour stocker le chemin du fichier de projet
        self.projet_maitre_nom_sans_extension = None
        self.data_dir = os.path.join(self.basepath, 'projet_local')
        # Dossier local où les couches sont stockées :                
        self.local_folder = self.basepath + "/projet_local/"  
        #self.local_folder= os.path.join(self.basepath, 'projet_local')
        self.VarConserver=True
        self.VarAjouter=False
        self.VarChanger=False
        self.VarSupprimer=False
        self.DicoVide=True
        self.DicoProj={}
        
        #récupération du Dictionnaire de projets "suivis" par le plugin  
        Dico = {}
        #DicoProj[projet_maitre_name]=[projet_maitre_root,projet_maitre_url,chemin,project_local_name,project_qgs_name,liste_locale_des_couches] 
        file_name_2 = 'bound_projet_dictionnary.csv'
        csv_file = os.path.join(self.local_folder, file_name_2)
        try:
            with open(csv_file, mode='r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=';')
                #QMessageBox.information(None, "Debug", " DicoProjet : "+ str(file))
                for ligne in reader:
                     # ligne[0]=projet_maitre_name, 
                     # ligne[1]=projet_maitre_root, 
                     # 2 = projet_maitre_url, 
                     # 3 = chemin,
                     # 4 = project_local_name, 
                     # 5 = project_qgs_name,
                     # 6 =liste_locale_des_couches, 
                     
                     Dico[ligne[0]]=[ligne[1],ligne[2],ligne[3],ligne[4],ligne[5],ligne[6]]
            
            self.DicoProj=Dico 
            if len(Dico) != 0: self.DicoVide=False       
        except FileNotFoundError:
            self.DicoProj={} 
            return
        
                
        
#####################################################################################
       
class MainPluginBPC(object):
      
    def __init__(self,iface):
        self.name = "BoundProjectCopier"
        # Initialise et sauvegarde l'interface QGIS en cours
        self.iface = iface
        self.dossier_plugin = os.path.dirname(__file__)
        # Création d'une instance de DataManager
        self.data_manager = DataManager()
        
    def initGui(self):
        #déclaration des actions élémentaires
        #menuIcon = getThemeIcon("BPC_icon.jpg")
        #menuIcon = getThemeIcon("Fichier_8x32.png")
        #menuIcon = getThemeIcon("Icone_1_15.png")
        menuIcon = getThemeIcon("Icone_1_15.jpg")
        self.action = QAction(QIcon(menuIcon),"BoundProjectCopier",self.iface.mainWindow())
        self.action.setText("BoundProjectCopier")

        menuIcon1 = resolve("about.png")
        self.about = QAction(QIcon(menuIcon1), "A propos ...", self.iface.mainWindow())
        self.about.setText("A propos ...")
        
        #Connection de la commande à l'action PYQT5
        self.action.triggered.connect(self.run)
        self.about.triggered.connect(self.doInfo)
        
        # Add toolbar button and menu item
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("BoundProjectCopier", self.action)


    def unload(self): 
        # Remove the plugin menu item and icon
        self.iface.removePluginMenu("BoundProjectCopier",self.action)
        self.iface.removeToolBarIcon(self.action)
    
    def doInfo(self):
        self.AboutDialog_BPC()

 
    def run(self):
        basepath=get_plugin_directory() #  est le répertoire où se trouve le plugin
        data_dir = os.path.join(basepath, 'projet_local')
        # Dossier local où les couches sont stockées :                
        local_folder = basepath + "/projet_local/"  
        #############################################################################################################
        # Vérifications de la présence des données d'un projet copié sinon choix du projet et première copie
        #############################################################################################################
        # Test de première utilisation:
        # on teste la présence en local d'un sous dossier projet_local
        # s'il il n'existe pas c'est la première utilisation du plugin, on le crée.
        
        if not os.path.exists(data_dir):
                # On ferme tout projet ouvert par précaution ! Suite au test avec Cédric... 
                QgsProject.instance().clear()
                os.makedirs(data_dir)
                QMessageBox.information(None,"information:","Bonjour, c'est la première utilisation de l'outil sur ce poste : " +
                        '\n'+'\n'+ "Il faut donc choisir un projet qgis..."+
                        '\n'+'\n'+ "le projet qgis choisi et les couches nécessaires qu'il contient vont être recopiés localement dans un dossier de votre choix,"+
                        '\n'+'\n'+ " L'"+'outil Bound Project Copier permettra par la suite de vérifier que projet et couches locales sont à jour par rapport au projet "maitre" initial.'
                        ) 

                self.showInitialDialog()            
        else :               
                self.showSecondDialog()

    def showInitialDialog(self):
        # Cas de la première utilisation sur un poste: on va recopier couches et projet et créer des rapports
        from .InitialDialog_BPC import InitialDialog_BPC
        self.dialogInitial = InitialDialog_BPC(self.data_manager)
        # self.dialog.show() 
        # Utilisez show() pour une fenêtre non modale
        # l'utilisateur peut continuer à interagir avec d'autres fenêtres de l'application tout en laissant cette fenêtre ouverte
        self.dialogInitial.exec_() 
        # l'utilisateur doive fermer cette fenêtre avant de pouvoir continuer à utiliser le reste de l'application, 

    def showSecondDialog(self):
        from .SecondDialog_BPC import SecondUseDialog_BPC
        self.dialogSecond = SecondUseDialog_BPC(self.data_manager)
        #self.dialog.show()
        self.dialogSecond.exec_()
        