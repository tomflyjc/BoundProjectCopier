# -*- coding: utf-8 -*-
# Python 3

"""
/***************************************************************************
 Fichier des fonctions du plugin BoundProjectCopier

Produit une copie locale d'un projet donné (couches et projet QGIS) ainsi 
que des tableaux de rapport de dernière copie/mise à jour des couches du projet et du projet lui-même
Vérifie ensuite au lancement si une couche ou le projet a été mis à jour pour garder à jour la version locale.
                              -------------------
        begin                : 2025-06-16 
        deployment           :   
        copyright            : (C) 2025 par Jean-Christophe Baudin 
        email                : jean-christophe.baudin@cote-dor.gouv.fr
 ***************************************************************************/
 icônes produites par M. Julie Briand (Bachelor of Technology in Multimedia and Internet) 
 contact: julie.briand35@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
"""
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import *
from qgis.utils import iface
from qgis.core import *
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
                       )
"""
from qgis.PyQt.QtWidgets import QDialog, QLabel, QPushButton, QComboBox, QMessageBox
from qgis.PyQt.QtCore import Qt, QSize, QRect, QFile
from qgis.core import QgsProject, QgsMapLayer

import shutil

from pathlib import *
import sys
import os

from .About_BPC  import AboutDialog_BPC
from .BoundProjectCopier import DataManager
from project_updater import *

# Get the directory of the current script
current_dir = Path(__file__).parent

# Add the current directory to the Python path
if current_dir not in sys.path:
    sys.path.append(str(current_dir))
    
from project_updater import *

class SuppressDialog_BPC(QDialog):
    def __init__(self, data_manager):
        super().__init__()
        self.data_manager = data_manager
        self.setupUi()

    def setupUi(self):
        
        self.setObjectName("Dialog")
        self.resize(QSize(500, 200))

        self.label10 = QLabel(self)
        self.label10.setGeometry(QRect(15, 20, 450, 18))
        self.label10.setObjectName("label10")
        self.label10.setText("Choisir le projet à supprimer:")

        self.Suppr_ComboBox = QComboBox(self)
        self.Suppr_ComboBox.setGeometry(QRect(100, 45, 180, 23))
        self.Suppr_ComboBox.setObjectName("Proj_Suppr_ComboBox")

        self.Liste_projet = [""]
        for proj_maitre_name in list(self.data_manager.DicoProj.keys()):
            self.Liste_projet.append(proj_maitre_name)
        self.Liste_projet.sort()
        for projet in self.Liste_projet:
            self.Suppr_ComboBox.addItem(projet)

        self.aboutButton = QPushButton(self)
        self.aboutButton.setGeometry(QRect(15, 150, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText("A propos...")

        self.WorkButtonSuppr = QPushButton(self)
        self.WorkButtonSuppr.setGeometry(QRect(100, 150, 300, 23))
        self.WorkButtonSuppr.setObjectName("WorkButtonSuppr")
        self.WorkButtonSuppr.setText("Supprimer le projet local choisi!")

        self.CloseButton = QPushButton(self)
        self.CloseButton.setGeometry(QRect(410, 150, 80, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText("Quitter!")

        self.aboutButton.clicked.connect(self.doAbout)
        self.WorkButtonSuppr.clicked.connect(self.Suppr)
        self.CloseButton.clicked.connect(self.reject)

        self.retranslateUi()

    def retranslateUi(self):
        self.setWindowTitle("BoundProjectCopier")

    def doAbout(self):
        from .About_BPC import AboutDialog_BPC
        d = AboutDialog_BPC.Dialog()
        d.exec_()

    def Suppr(self):
        Selection_projet_Suppr = self.Suppr_ComboBox.currentText()
        if Selection_projet_Suppr:  # Vérifiez si un projet est sélectionné
            for projet_maitre_name in list(self.data_manager.DicoProj.keys()):
                if Selection_projet_Suppr == projet_maitre_name:
                    chemin = self.data_manager.DicoProj[projet_maitre_name][2]
                    if os.path.exists(chemin):
                        shutil.rmtree(chemin)
                        print(f"Le dossier '{chemin}' a été supprimé avec succès.")
                        QMessageBox.information(None, "Avertissement : ", f"Le dossier '{chemin}' a été supprimé avec succès.")
                    
                    else:
                        QMessageBox.information(None, "Avertissement : ", f"Le dossier '{chemin}' n'existe pas.")
                        print(f"Le dossier '{chemin}' n'existe pas.")
                    
                    # mise à jour de la comboBox dans cette page
                    self.Liste_projet.remove(projet_maitre_name)
                    self.Liste_projet.sort()
                    # Effacer tous les éléments actuels de la QComboBox
                    self.Suppr_ComboBox.clear()
                    for projet in self.Liste_projet:
                        self.Suppr_ComboBox.addItem(projet)
                    # mise à jour de la sauvegarde du dictionnaire avec un projet en moins
                    del self.data_manager.DicoProj[projet_maitre_name]
                    file_name ='bound_projet_dictionnary.csv'
                    txt_file = os.path.join(self.data_manager.local_folder, file_name )
                    # Writing to a CSV file
                    with open(txt_file, mode='w', newline='', encoding='utf-8') as file:
                        writer = csv.writer(file, delimiter=';')  # Specify the delimiter here
                        for key, values in self.data_manager.DicoProj.items():
                            writer.writerow([key] + values)
                    
                    # Mise à jour éventuelle du dernier projet dans le fichier texte
                    # si le projet actuel est le projet à supprimer on le suplante dans le fichier txt par un autre du dictionanire
                    file_name_1='chemin_dernier_projet_maitre.txt'
                    texte_file_1 = os.path.join(self.data_manager.local_folder, file_name_1 )
                    if len(self.data_manager.DicoProj) == 0:
                        print("Le dictionnaire est vide.")
                        self.data_manager.DicoVide=True
                    else:
                        print("Le dictionnaire n'est pas vide.")
                        # Obtenir la première clé
                        premiere_cle = next(iter(self.data_manager.DicoProj))
                        # Lire la valeur du chemin absolu pour la première clé
                        # attention on compte les attributs à partant de 0
                        premiere_valeur_chemin = self.data_manager.DicoProj[premiere_cle][1] # le deuxième attribut est DicoProj[premiere_cle][1]
                        with open(texte_file_1, mode='w', encoding='utf-8') as texte:
                            texte.write(premiere_valeur_chemin)
                    
                    self.data_manager.VarSupprimer=False     
                    self.data_manager.VarConserver=True   
                    self.data_manager.projet_maitre_url=premiere_valeur_chemin                        
                    
                    QMessageBox.information(None, "Avertissement : ", f"Le projet '{Selection_projet_Suppr}' ne sera plus recopié et mis à jour localement.")
                    print(f"Le projet '{Selection_projet_Suppr}' ne sera plus recopié et mis à jour localement.")