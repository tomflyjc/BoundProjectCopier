# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import QFile, QSize, Qt
from qgis.PyQt.QtGui import QFont, QPalette, QColor, QBrush, QPixmap, QImage
from qgis.PyQt.QtWidgets import QVBoxLayout, QLabel, QTextEdit, QPushButton, QDialog

import os
import sys

# Fonction de reconstruction du chemin absolu vers la ressource image
def resolve(name, basepath=None):
    if not basepath:
        basepath = os.path.dirname(os.path.realpath(__file__))
    return os.path.join(basepath, name)

def getThemeIcon(theName):
    basepath = os.path.dirname(os.path.realpath(__file__))
    myDefPathIcons = os.path.join(basepath, "icons", theName)
    if QFile.exists(myDefPathIcons):
        return myDefPathIcons
    else:
        return ""

class AboutDialog_BPC(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Bound Project Copier")
        self.setGeometry(10, 10, 350, 400)

        layout = QVBoxLayout()

        # Ajout de l'icône
        self.labelImage = QLabel()
        icon_path = getThemeIcon("BPC_icon.jpg")
        if icon_path:
            carIcon = QImage(icon_path)
            self.labelImage.setPixmap(QPixmap.fromImage(carIcon))
            self.labelImage.setAlignment(Qt.AlignCenter)
            layout.addWidget(self.labelImage)

        # Ajout du titre
        self.label_2 = QLabel("Bound Project Copier V0")
        font = QFont()
        font.setPointSize(15)
        font.setBold(True)
        self.label_2.setFont(font)
        layout.addWidget(self.label_2)

        # Ajout de la zone de texte
        self.textEdit = QTextEdit()
        self.textEdit.setReadOnly(True)
        self.textEdit.setHtml(
            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">"
            "p, li { white-space: pre-wrap; }"
            "</style></head><body style=\" font-family:'Sans Serif'; font-size:8pt; font-weight:300; font-style:normal;\">"
            "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\">"
            "<span style=\" font-weight:600;\">BoundProjectCopier :</span> Ce plugin est conçu pour disposer d'une copie locale d'un projet maître toujours à jour."
            "Nous travaillons souvent avec des projets qui sont des copies locales de projet Maître qui utilisent des données 'à plat'."
            "Tôt ou tard, les données récopiées localement diffèrent des données sources faute d'avoir été mises à jour."
            "Cette extension vérifie si le projet Maître a été modifié, si les couches qui le composent ont été modifiées et répercute ces modifications en local."
            "Cette extension ne fait pas partie du moteur de Qgis. Toute demande est à adresser à l'auteur : </p>"
            "<p style=\"margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">"
            "<b>jean-christophe.baudin@cote-dor.gouv.fr</b><br><b>DDT21 SUCAT/BGAT</b><br>"
            "<br><i>Version 0.0.1 (16 juin 2025).</i></p></body></html>"
        )
        layout.addWidget(self.textEdit)

        # Ajout du bouton
        self.pushButton = QPushButton("OK")
        self.pushButton.clicked.connect(self.close)
        layout.addWidget(self.pushButton)

        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    dialog = Fenetre2()
    dialog.show()
    sys.exit(app.exec_())
